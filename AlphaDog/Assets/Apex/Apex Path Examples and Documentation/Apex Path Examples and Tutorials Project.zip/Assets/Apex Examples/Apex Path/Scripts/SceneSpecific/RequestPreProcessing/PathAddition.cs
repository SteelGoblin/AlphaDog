﻿#pragma warning disable 1591
namespace Apex.Examples.SceneSpecific.RequestPreProcessing
{
    using UnityEngine;

    public struct PathAddition
    {
        public bool prepend;

        public Vector3 point;
    }
}
