﻿/* Copyright © 2014 Apex Software. All rights reserved. */
namespace Apex.AI
{
    /// <summary>
    /// Basic representation of compare operators
    /// </summary>
    public enum CompareOperator
    {
        /// <summary>
        /// No comparison, e.g. force a false return value
        /// </summary>
        None = 0,

        /// <summary>
        /// A &lt; B
        /// </summary>
        LessThan,

        /// <summary>
        /// A &lt;= B
        /// </summary>
        LessThanOrEquals,

        /// <summary>
        /// A == B
        /// </summary>
        Equals,

        /// <summary>
        /// A != B
        /// </summary>
        NotEquals,

        /// <summary>
        /// A &gt;= B
        /// </summary>
        GreaterThanOrEquals,

        /// <summary>
        /// A &gt; B
        /// </summary>
        GreaterThan
    }
}