﻿/* Copyright © 2014 Apex Software. All rights reserved. */
namespace Apex.Editor
{
    public static class MouseButton
    {
        public const int left = 0;
        public const int right = 1;
        public const int middle = 2;
    }
}
