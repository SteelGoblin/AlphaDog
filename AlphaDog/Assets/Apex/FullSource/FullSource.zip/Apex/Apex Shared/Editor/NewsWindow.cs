﻿/* Copyright © 2014 Apex Software. All rights reserved. */
namespace Apex.Editor
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Net;
    using System.Xml;
    using System.Xml.Linq;
    using Apex.Editor.Versioning;
    using UnityEditor;
    using UnityEngine;

    [InitializeOnLoad]
    public class NewsWindow : EditorWindow
    {
        private const int _loadCount = 5;

        private Vector2 _scrollPos;
        private ApexSettings _settings;
        private List<NewsItem> _news;
        private bool _loading;

        static NewsWindow()
        {
            if (!EditorApplication.isPlayingOrWillChangePlaymode)
            {
                EditorApplication.delayCall += CheckAutoShow;
            }
        }

        private static void CheckAutoShow()
        {
            EditorApplication.delayCall -= CheckAutoShow;
            if (EditorApplication.isPlaying)
            {
                return;
            }

            ApexSettings settings;
            if (!ApexSettings.TryGetSettings(out settings) && settings == null)
            {
                return;
            }

            if (!settings.timeToCheckNews)
            {
                return;
            }

            settings.NewsChecked();

            EditorAsync.Execute(
                () => IssueRequest("api/News/GetLatestNews", settings),
                xml =>
                {
                    if (string.IsNullOrEmpty(xml))
                    {
                        return;
                    }

                    var doc = XDocument.Parse(xml);
                    if (doc == null || doc.Root == null)
                    {
                        return;
                    }

                    var latestNewsDate = XmlConvert.ToDateTime(doc.Root.Value, XmlDateTimeSerializationMode.Utc);
                    if (latestNewsDate == DateTime.MinValue)
                    {
                        return;
                    }

                    if (!settings.lastNewsDate.HasValue || settings.lastNewsDate < latestNewsDate)
                    {
                        settings.LatestNewsRetrieved(latestNewsDate);

                        if (EditorUtility.DisplayDialog("Apex News", "An unread Apex news message is available, do you wish to view it?", "Yes", "No"))
                        {
                            SharedMenuExtentions.ShowNewsWindow();
                        }
                    }
                });
        }

        private static IEnumerable<NewsItem> GetNews(ApexSettings settings, int start)
        {
            var client = new WebClient
            {
                BaseAddress = EnsureTrailingSlash(settings.updateCheckBaseUrl)
            };

            string newsData = IssueRequest(string.Format("api/News/GetNews?start={0}&count={1}", start, _loadCount), settings);
            if (string.IsNullOrEmpty(newsData))
            {
                yield break;
            }

            var newsXml = XDocument.Parse(newsData);
            XNamespace ns = newsXml.Root.Attribute("xmlns").Value;

            foreach (var p in newsXml.Root.Elements(ns + "NewsItem"))
            {
                yield return new NewsItem
                {
                    text = p.Element(ns + "text").Value,
                    link = p.Element(ns + "link").Value,
                    date = XmlConvert.ToDateTime(p.Element(ns + "date").Value, XmlDateTimeSerializationMode.Utc).ToLocalTime()
                };
            }
        }

        private static string IssueRequest(string request, ApexSettings settings)
        {
            var client = new WebClient
            {
                BaseAddress = EnsureTrailingSlash(settings.updateCheckBaseUrl)
            };

            try
            {
                client.Headers.Add("Accept", "application/xml");
                return client.DownloadString(request);
            }
            catch
            {
                return null;
            }
            finally
            {
                client.Dispose();
            }
        }

        private static string EnsureTrailingSlash(string url)
        {
            if (url.EndsWith("/"))
            {
                return url;
            }

            return url + "/";
        }

        private static string XmlSingleValue(string xml)
        {
            var doc = XDocument.Parse(xml);
            if (doc == null || doc.Root == null)
            {
                return string.Empty;
            }

            return doc.Root.Value;
        }

        private void OnEnable()
        {
            this.minSize = new Vector2(490f, 350f);

            if (!ApexSettings.TryGetSettings(out _settings) && _settings == null)
            {
                return;
            }

            _settings.NewsChecked();

            EditorAsync.Execute(
                () => GetNews(_settings, 0),
                news =>
                {
                    _news = new List<NewsItem>(news);
                    if (_news.Count > 0)
                    {
                        _settings.LatestNewsRetrieved(_news[0].date);
                    }
                });
        }

        private void OnGUI()
        {
            if (_news == null)
            {
                GUILayout.FlexibleSpace();
                EditorGUILayout.LabelField("Loading...", Styles.centeredText);
                GUILayout.FlexibleSpace();
                Repaint();
                return;
            }

            _settings.checkNews = EditorGUILayout.ToggleLeft("Inform of unread News at start-up.", _settings.checkNews);
            if (_settings.isDirty)
            {
                _settings.SaveChanges();
            }

            if (_news.Count == 0)
            {
                GUILayout.FlexibleSpace();
                EditorGUILayout.LabelField("Currently no news", Styles.centeredText);
                GUILayout.FlexibleSpace();
                return;
            }

            _scrollPos = EditorGUILayout.BeginScrollView(_scrollPos, false, false, GUIStyle.none, GUI.skin.verticalScrollbar, GUIStyle.none);
            foreach (var n in _news)
            {
                EditorGUILayout.Separator();
                EditorGUILayout.BeginVertical("Box");
                EditorGUILayout.LabelField(n.date.ToString("g", DateTimeFormatInfo.CurrentInfo), Styles.dateStyle);
                EditorGUILayout.LabelField(n.text, Styles.outputTextStyle);
                if (!string.IsNullOrEmpty(n.link))
                {
                    if (GUILayout.Button("View More", Styles.linkStyle))
                    {
                        Application.OpenURL(n.link);
                    }

                    EditorGUIUtility.AddCursorRect(GUILayoutUtility.GetLastRect(), MouseCursor.Link);
                }
                
                EditorGUILayout.EndVertical();
            }

            if (!_loading && ((_news.Count % _loadCount) == 0) && GUILayout.Button("Load More"))
            {
                _loading = true;
                EditorAsync.Execute(
                () => GetNews(_settings, _news.Count),
                news =>
                {
                    _news.AddRange(news);
                    _loading = false;
                    Repaint();
                });
            }

            EditorGUILayout.EndScrollView();
        }

        private class NewsItem
        {
            public string text { get; set; }

            public string link { get; set; }

            public DateTime date { get; set; }
        }

        private class Styles
        {
            private static GUIStyle _outputTextStyle;
            private static GUIStyle _linkStyle;
            private static GUIStyle _dateStyle;
            private static GUIStyle _centeredText;

            internal static GUIStyle outputTextStyle
            {
                get
                {
                    if (_outputTextStyle == null)
                    {
                        _outputTextStyle = new GUIStyle(EditorStyles.label)
                        {
                            wordWrap = true,
                            richText = true
                        };
                    }

                    return _outputTextStyle;
                }
            }

            internal static GUIStyle linkStyle
            {
                get
                {
                    if (_linkStyle == null)
                    {
                        _linkStyle = new GUIStyle(EditorStyles.label);
                        _linkStyle.normal.textColor = new Color(163 / 255f, 73 / 255f, 164 / 255f);
                        _linkStyle.stretchWidth = false;
                    }

                    return _linkStyle;
                }
            }

            internal static GUIStyle dateStyle
            {
                get
                {
                    if (_dateStyle == null)
                    {
                        _dateStyle = new GUIStyle(EditorStyles.label)
                        {
                            fontStyle = FontStyle.Italic
                        };
                    }

                    return _dateStyle;
                }
            }

            internal static GUIStyle centeredText
            {
                get
                {
                    if (_centeredText == null)
                    {
                        _centeredText = new GUIStyle(EditorStyles.label)
                        {
                            alignment = TextAnchor.MiddleCenter
                        };
                    }

                    return _centeredText;
                }
            }
        }
    }
}
