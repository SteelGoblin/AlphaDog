﻿/* Copyright © 2014 Apex Software. All rights reserved. */
namespace Apex.Editor
{
    internal static class UIResources
    {
        //Product Icons
        internal static readonly PngResource ApexLogo = new PngResource("apexlogo", 16, 16);
    }
}
