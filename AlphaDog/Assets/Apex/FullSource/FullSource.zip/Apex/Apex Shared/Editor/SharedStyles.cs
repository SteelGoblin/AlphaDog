﻿/* Copyright © 2014 Apex Software. All rights reserved. */
namespace Apex.Editor
{
    using UnityEditor;
    using UnityEngine;

    public static class SharedStyles
    {
        private static readonly Color defaultTextColor = new Color(235f / 255f, 235f / 255f, 235f / 255f, 0.75f);
        private static BuiltInStyles _builtIn;

        public static BuiltInStyles BuiltIn
        {
            get
            {
                if (_builtIn == null)
                {
                    _builtIn = new BuiltInStyles();
                }

                return _builtIn;
            }
        }

        public sealed class BuiltInStyles
        {
            internal BuiltInStyles()
            {
                var unitySkinTextColor = EditorGUIUtility.isProSkin ? defaultTextColor : Color.black;

                objectSelectorBoxNormal = new GUIStyle(EditorStyles.label)
                {
                    alignment = TextAnchor.MiddleLeft,
                    wordWrap = false
                };

                objectSelectorBoxNormal.normal.textColor = unitySkinTextColor;
                objectSelectorBoxNormal.padding = new RectOffset(objectSelectorBoxNormal.padding.left + 5, objectSelectorBoxNormal.padding.right, objectSelectorBoxNormal.padding.top, objectSelectorBoxNormal.padding.bottom);

                objectSelectorBoxActive = new GUIStyle("MeTransitionSelectHead")
                {
                    fontStyle = FontStyle.Bold,
                    alignment = TextAnchor.MiddleLeft,
                    wordWrap = false
                };

                objectSelectorBoxActive.normal.textColor = defaultTextColor;
                objectSelectorBoxActive.padding = new RectOffset(objectSelectorBoxActive.padding.left + 5, objectSelectorBoxActive.padding.right, objectSelectorBoxActive.padding.top, objectSelectorBoxActive.padding.bottom);

                searchFieldStyle = new GUIStyle("SearchTextField");
                searchFieldStyle.normal.textColor = unitySkinTextColor;

                searchCancelButton = new GUIStyle("SearchCancelButton");
                searchCancelButtonEmpty = new GUIStyle("SearchCancelButtonEmpty");

                centeredText = new GUIStyle(EditorStyles.label)
                {
                    alignment = TextAnchor.MiddleCenter
                };

                wrappedText = new GUIStyle(EditorStyles.label)
                {
                    wordWrap = true
                };
            }

            public GUIStyle objectSelectorBoxNormal
            {
                get;
                private set;
            }

            public GUIStyle objectSelectorBoxActive
            {
                get;
                private set;
            }

            public GUIStyle searchFieldStyle
            {
                get;
                private set;
            }

            public GUIStyle searchCancelButton
            {
                get;
                private set;
            }

            public GUIStyle searchCancelButtonEmpty
            {
                get;
                private set;
            }

            public GUIStyle centeredText
            {
                get;
                private set;
            }

            public GUIStyle wrappedText
            {
                get;
                private set;
            }
        }
    }
}
