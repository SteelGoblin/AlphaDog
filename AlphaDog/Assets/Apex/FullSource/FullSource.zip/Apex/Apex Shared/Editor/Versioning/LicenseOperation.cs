﻿/* Copyright © 2014 Apex Software. All rights reserved. */
namespace Apex.Editor.Versioning
{
    internal enum LicenseOperation
    {
        None,
        Activation,
        Deactivation
    }
}
