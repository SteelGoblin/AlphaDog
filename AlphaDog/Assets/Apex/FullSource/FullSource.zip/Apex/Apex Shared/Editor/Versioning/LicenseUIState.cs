﻿/* Copyright © 2014 Apex Software. All rights reserved. */
namespace Apex.Editor.Versioning
{
    internal enum LicenseUIState
    {
        None,
        CollectingInput,
        Processing
    }
}
