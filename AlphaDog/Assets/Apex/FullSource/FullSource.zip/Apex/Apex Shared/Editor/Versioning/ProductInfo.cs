﻿/* Copyright © 2014 Apex Software. All rights reserved. */
namespace Apex.Editor.Versioning
{
    using System;
    using Licensing;

    public class ProductInfo
    {
        private bool _licenseRequired;

        public string name { get; set; }

        public string generalName { get; set; }

        public Version installedVersion { get; set; }

        public Version newestVersion { get; set; }

        public Version latestPatch { get; set; }

        public ProductType type { get; set; }

        public string storeUrl { get; set; }

        public string productUrl { get; set; }

        public string licenseSourceUrl { get; set; }

        public string description { get; set; }

        public string changeLogPath { get; set; }

        public ProductStatus status
        {
            get
            {
                if (this.installedVersion == null)
                {
                    if (string.IsNullOrEmpty(this.storeUrl))
                    {
                        return ProductStatus.ComingSoon;
                    }

                    return ProductStatus.ProductAvailable;
                }

                if (this.newestVersion == null || this.installedVersion >= this.newestVersion)
                {
                    if (this.latestPatch != null && this.latestPatch > this.installedVersion)
                    {
                        return ProductStatus.PatchAvailable;
                    }

                    return ProductStatus.UpToDate;
                }
                else
                {
                    return ProductStatus.UpdateAvailable;
                }
            }
        }

        internal bool isInstalled
        {
            get { return (this.status != ProductStatus.ComingSoon) && (this.status != ProductStatus.ProductAvailable); }
        }

        internal IProductIdentifier product
        {
            get;
            set;
        }

        internal bool requiresLicense
        {
            get { return (this.product != null && this.product.requiresLicense) || _licenseRequired; }
            set { _licenseRequired = value; }
        }

        internal LicenseStatus licenseStatus
        {
            get;
            private set;
        }

        internal LicenseOperation pendingOperation
        {
            get;
            private set;
        }

        internal LicenseUIState licenseUIState
        {
            get;
            set;
        }

        internal string licenseEmailInput
        {
            get;
            set;
        }

        internal string licenseKeyInput
        {
            get;
            set;
        }

        internal LicensingActionResult lastLicensingResult
        {
            get;
            private set;
        }

        internal PngResource icon { get; set; }

        internal bool expanded { get; set; }

        internal bool newUpdateAvailable { get; set; }

        internal void ActivateLicense(Action cb)
        {
            OnLicenseActionStart(LicenseOperation.Activation);
            EditorAsync.Execute(
                () => LicenseManager.ActivateLicense(this.product, this.licenseEmailInput, this.licenseKeyInput),
                (res) =>
                {
                    this.licenseKeyInput = string.Empty;
                    ConsumeLicenseResult(res);
                    cb();
                });
        }

        internal void ReactivateLicense(Action cb)
        {
            OnLicenseActionStart(LicenseOperation.Activation);
            EditorAsync.Execute(
                () => LicenseManager.ReactivateLicense(this.product),
                (res) =>
                {
                    ConsumeLicenseResult(res);
                    cb();
                });
        }

        internal void DeactivateLicense(Action cb)
        {
            OnLicenseActionStart(LicenseOperation.Deactivation);
            EditorAsync.Execute(
                () => LicenseManager.DeactivateLicense(this.product, true),
                (res) =>
                {
                    ConsumeLicenseResult(res);
                    cb();
                });
        }

        internal void CheckLicense(Action cb)
        {
            OnLicenseActionStart(LicenseOperation.None);
            EditorAsync.Execute(
                () => LicenseManager.ValidateLicense(this.product),
                (res) =>
                {
                    ConsumeLicenseResult(res);
                    cb();
                });
        }

        internal void ReadLicense()
        {
            this.licenseStatus = LicenseManager.GetLicenseStatus(this.product);
        }

        internal void RemoveLicense(Action cb)
        {
            OnLicenseActionStart(LicenseOperation.None);
            EditorAsync.Execute(
                () => LicenseManager.RemoveLicense(this.product),
                (res) =>
                {
                    ConsumeLicenseResult(res);
                    cb();
                });
        }

        private void OnLicenseActionStart(LicenseOperation op)
        {
            if (this.lastLicensingResult != null)
            {
                this.expanded = false;
                this.lastLicensingResult = null;
            }

            this.licenseUIState = LicenseUIState.Processing;
            this.pendingOperation = op;
        }

        internal void ConsumeLicenseResult(LicensingActionResult res)
        {
            if (!res.successful)
            {
                this.expanded = true;
            }

            if (res.status != LicenseStatus.Unresolved)
            {
                this.pendingOperation = LicenseOperation.None;
            }

            this.lastLicensingResult = res;
            this.licenseStatus = res.status;
            this.licenseUIState = LicenseUIState.None;
        }
    }
}
